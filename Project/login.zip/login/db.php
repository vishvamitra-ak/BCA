<?php

$con=mysql_connect('localhost','root','xyzzy');
mysql_select_db('project_test',$con);


?>