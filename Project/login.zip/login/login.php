<form id="formID" class="form-signin" method="post" action="logcheck.php">
        <h2 class="style1" >Sign in</h2>
        <input name="username" type="text" class="validate[required]" class="input-block-level" placeholder="Enter username">
        <input name="password" type="password" class="validate[required]" class="input-block-level" placeholder="Enter Password">
       <p><a href="forgot_password.php" class="style2">Forgot Password? Click here</a></p>
	    
        <button class="btn btn-large btn-primary" type="submit">Sign in</button>
      </form>	
