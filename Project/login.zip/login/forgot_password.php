<?php error_reporting(0); ?>
<!DOCTYPE html>
<!--[if lt IE 7]> <html class="lt-ie9 lt-ie8 lt-ie7" lang="en"> <![endif]-->
<!--[if IE 7]> <html class="lt-ie9 lt-ie8" lang="en"> <![endif]-->
<!--[if IE 8]> <html class="lt-ie9" lang="en"> <![endif]-->
<!--[if gt IE 8]><!--> <html lang= "en"> <!--<![endif]-->
<head>
  <meta charset= "utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
  <title>Login Form</title>
  <link rel="stylesheet" href="css/login_css.css">
  <!--[if lt IE 9]><script src="//html5shim.googlecode.com/svn/trunk/html5.js"></script><![endif]-->
  
</head>
<body>
  <section class="container">
    <div class="login">
      <h1>Please Enter Your Username to get Password.</h1>
					
					<form class="form-horizontal" action="forgot_password1.php" method="post">
						<fieldset>
							Username
							<div class="input-prepend" title= "Username" data-rel= "tooltip">
								<span class="add-on"><i class="icon-user"></i></span><input autofocus class="input-large span10" name="user_name" id="user_name" type="text"/>
							</div>
							
							<div class="clearfix"></div>

						
							<div class="clearfix"></div>

							<p class="center span5">
							<button type="submit" class="btn btn-primary">Login</button>
							</p>
						</fieldset>
					</form>
	</div>

</section>
</body>
</html>

